<div class="row">
<div class="col-md-12">
	
    <?php echo render_select('series_id',$series_id,array('id','name'),'series_name'); ?>
</div>
</div>