
<div class="row">
	
	<div class="col-md-12">
	    <?php echo render_select('warehouse_id',$warehouses,array('warehouse_id','warehouse_name'),'warehouse_name'); ?>
	</div>
</div>